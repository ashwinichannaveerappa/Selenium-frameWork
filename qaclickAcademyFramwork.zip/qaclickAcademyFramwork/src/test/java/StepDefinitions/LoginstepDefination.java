package StepDefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import cucumber.api.junit.Cucumber;

import java.util.concurrent.TimeUnit;

import org.junit.runner.RunWith;
import org.qaclickAcademy.DriverInstance.Base;
import org.qaclickAcademy.PageObjects.LandingPage;
import org.qaclickAcademy.PageObjects.LoginPage;
import org.qaclickAcadmy.testCases.HomePage;


public class LoginstepDefination extends Base{
Base b = new Base();
LandingPage lpm = new LandingPage(driver);
LoginPage lo = new LoginPage(driver);

	@Given("^Initiaize broser wth chrome$")
public void initiaize_broser_wth_chrome() throws Throwable {
		b.initializeDriver();
		
}

@Given("^navigate to the \"([^\"]*)\"$")
public void navigate_to_the(String arg1) throws Throwable {
driver.get(arg1);
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//to handle the pop up
System.out.println(lpm.getPopUpSize() );
if(lpm.getPopUpSize() > 0)
{
	lpm.getPopUp().click();
}

}

@Given("^click on login button$")
public void click_on_login_button() throws Throwable {
	lpm.getLogin().click();
}

@When("^User enters \"([^\"]*)\" and \"([^\"]*)\" and logs in$")
public void user_enters_and_and_logs_in(String arg1, String arg2) throws Throwable {
	lo.enterEmail().sendKeys(arg1);
	lo.enterPassword().sendKeys(arg2);
	lo.clickOnLogin().click();


}

@Then("^verify that user logged in successfully$")
public void verify_that_user_logged_in_successfully() throws Throwable {
}
}
