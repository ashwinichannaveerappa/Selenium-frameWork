package org.qaclickAcadmy.testCases;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.qaclickAcademy.DriverInstance.Base;
import org.qaclickAcademy.PageObjects.LandingPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class validateTitle extends Base {
	// log object initialize in each testcase
	public static Logger log = LogManager.getLogger(validateTitle.class.getName());


	@Test
	public void validate() {
		LandingPage landingpage = new LandingPage(driver);
		Assert.assertEquals(landingpage.getTitle().getText(), "FEATURED COURSES");
		log.info("Title is present");
		Assert.assertEquals(landingpage.getHeader().getText(), "AN ACADEMY TO LEARN EVERYTHING ABOUT TESTING");
		log.info("verified header title");

	}

}
