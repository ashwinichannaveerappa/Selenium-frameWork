package org.qaclickAcadmy.testCases;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.qaclickAcademy.DriverInstance.Base;
import org.qaclickAcademy.PageObjects.LandingPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class validateNavigationBar extends Base {
	//log object initialize n each testcase
	
	
public  static Logger log = LogManager.getLogger(validateNavigationBar.class.getName());

	@Test
	public void validationBar()
	{
		LandingPage lp = new LandingPage(driver);

		//isDisplayed returns true
		Assert.assertTrue(lp.getNavigationBar().isDisplayed());
		log.info("Navigation bar is present");


	}
	

}
