package org.qaclickAcadmy.testCases;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.qaclickAcademy.DataGenerator.DataGenerator;
import org.qaclickAcademy.DriverInstance.Base;
import org.qaclickAcademy.PageObjects.LandingPage;
import org.qaclickAcademy.PageObjects.LoginPage;
import org.testng.annotations.Test;


public class HomePage extends Base{

	//log object initialize n each testcase
public  static Logger log = LogManager.getLogger(HomePage.class.getName());


	@Test(dataProvider ="Excel", dataProviderClass = DataGenerator.class)

	public void basePageNavigation(String uname, String pwd) throws IOException
	{
		log.debug("Launch the appication");
		LandingPage lp =new LandingPage(driver);
		log.info("application successfully launched");
		log.debug("click on Login button");
		lp.getLogin().click();
		log.info("login window opened");
		
		LoginPage lo = new LoginPage(driver);
		lo.enterEmail().sendKeys(uname);
		lo.enterPassword().sendKeys(pwd);
		lo.clickOnLogin().click();
	}

}

