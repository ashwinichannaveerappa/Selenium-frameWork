package org.qaclickAcademy.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {

	public  WebDriver driver;


	//create a constructor
	public LandingPage(WebDriver driver)
	{
		this.driver=driver;
		//PageFactory.initElements(driver, this);  //to initialize PageFactory Object repository use this line
	}
	
//	@FindBy(css="a[href*=sign_in]")
	
//	WebElement loginlink;
	private By signin=By.cssSelector("a[href*='sign_in']");
	private By navigationBar= By.cssSelector(".nav.navbar-nav.navbar-right");
	private By titleText = By.cssSelector("#content h2");
	private By Header = By.cssSelector(".carousel-inner > .item h3");
	By popup=By.xpath("//button[text()='NO THANKS']");



	public WebElement getLogin()
	{
		return driver.findElement(signin);
	}
	
	public WebElement getTitle()
	{
		return driver.findElement(titleText);
	}
	
	
	public WebElement getNavigationBar()
	{
		return driver.findElement(navigationBar);
	}
	
	public WebElement getHeader()
	{
		return driver.findElement(Header);
	}
	
	public int getPopUpSize()
	{
		return driver.findElements(popup).size();
	}
	
	public WebElement getPopUp()
	{
		return driver.findElement(popup);
	}
	
}
