package org.qaclickAcademy.DataGenerator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;

public class DataGenerator {

	@DataProvider(name="Excel")
	
	public static Object[][] LoginData() throws IOException
	{
		//Connect to Excel
		FileInputStream fis = new FileInputStream("./TestData/TestDataWorkbook.xlsx");
		
		//get the Worrkbook
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		//get the sheet
		XSSFSheet loginSheet = workbook.getSheet("login");
		
		//get the number of rows
		int numberOfData =loginSheet.getPhysicalNumberOfRows();

		//to get the number of columns
		System.out.println(numberOfData);
		
		int numberOfColumns = loginSheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println(numberOfColumns);

		//store it in the object array
		
		Object [] [] testData = new Object[numberOfData][numberOfColumns];
		
		for(int i= 0; i<numberOfData;i++)
		{
			 
			XSSFRow row = loginSheet.getRow(i);
			XSSFCell email = row.getCell(0);
			XSSFCell pwd = row.getCell(1);

			testData[i][0] =email.getStringCellValue();
			testData[i][1] = pwd.getStringCellValue();


		}
		//return testData 
		return testData;
		
		
		
	}

}
