package org.qaclickAcademy.DataGenerator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class DBConnection {
	
	public void connectToDB() throws SQLException
	{
		String host ="localhost";
		String port="3306";
		String sql ="select * from employeeinfo where age=22";
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/QADBT", "root", "root");
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery(sql);
		while(rs.next())
		{
			System.out.println(rs.getString("name"));
			System.out.println(rs.getString("age"));			
		}
	}

}
