package org.qaclickAcademy.DriverInstance;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class Base {
	/*
	 * @Author Ashwini
	 * 
	 * @Description : To initialize the driver
	 */

	public static WebDriver driver;
	public static Properties props;

	@BeforeMethod
	public void initializeDriver() throws IOException

	{
		FileInputStream file = new FileInputStream("./Config/config.properties");
		props = new Properties();
		props.load(file);
		// to css the properties from the file
		// mvn test -Dbrowser=chrome
		// String browserName = System.getProperty("browser");

		String browserName = props.getProperty("browserName");
		String applicationURL = props.getProperty("applicationURL");

		if (browserName.contains("chrome")) {

			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			// to execute headless browser,in background chrome will be opened in binaries
			// so
			if (browserName.contains("headless")) {
				options.addArguments("headless");
			}
			driver = new ChromeDriver(options);
		} else if (browserName.contains("firefox")) {
			System.setProperty("webdriver.gecko.driver", "./Driver/geckodriver.exe");
			FirefoxOptions options = new FirefoxOptions();
			if (browserName.contains("headless")) {
				options.addArguments("-headless");
			}
			driver = new FirefoxDriver(options);

		} else if (browserName.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.ie.driver", "./Driver/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else if (browserName.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", "./Driver/MicrosoftWebDriver.exe");
			driver = new EdgeDriver();
		} else {
			// if it not equal by default create chrome browser instance
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			driver = new ChromeDriver();
		}
		driver.get(applicationURL);

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();

	}

	@AfterMethod
	public void closeDriver() {
		driver.quit();
		driver = null;
	}

	public void getScreenshot(String result) throws IOException {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("./FailureTestScreenShot/" + result + "screenshot.png"));

	}

}
